<?php
    include_once("koneksi.php");
  
    $query = mysqli_query($koneksi, "UPDATE karyawan SET nama_lengkap='Panji', jenis_kelamin='Pria' WHERE id='5'");
      
    if($query)
    {
        echo "Data berhasil di rubah, silahkan lihat database perusahaan dan lihat table karyawan dan lihat id 5";
    }
    else
    {
        echo "Data gagal di ubah";
    }
?>